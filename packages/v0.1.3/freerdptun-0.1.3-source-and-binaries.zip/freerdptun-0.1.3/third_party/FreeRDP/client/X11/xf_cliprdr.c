/**
 * FreeRDP: A Remote Desktop Protocol Implementation
 * X11 Clipboard Redirection
 *
 * Copyright 2010-2011 Vic Lee
 * Copyright 2015 Thincast Technologies GmbH
 * Copyright 2015 DI (FH) Martin Haimberger <martin.haimberger@thincast.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <freerdp/config.h>

#include <stdlib.h>
#include <errno.h>

#include <X11/Xlib.h>
#include <X11/Xatom.h>

#ifdef WITH_XFIXES
#include <X11/extensions/Xfixes.h>
#endif

#include <winpr/crt.h>
#include <winpr/assert.h>
#include <winpr/image.h>
#include <winpr/stream.h>
#include <winpr/clipboard.h>
#include <winpr/path.h>

#include <freerdp/utils/signal.h>
#include <freerdp/log.h>
#include <freerdp/client/cliprdr.h>
#include <freerdp/channels/channels.h>
#include <freerdp/channels/cliprdr.h>

#include <freerdp/client/client_cliprdr_file.h>

#include "xf_cliprdr.h"
#include "xf_event.h"
#include "xf_utils.h"

#define TAG CLIENT_TAG("x11.cliprdr")

#define MAX_CLIPBOARD_FORMATS 255

#define DEBUG_CLIPRDR(...) WLog_DBG(TAG, __VA_ARGS__)

typedef struct
{
	Atom atom;
	UINT32 formatToRequest;
	UINT32 localFormat;
	char* formatName;
	BOOL isImage;
} xfCliprdrFormat;

typedef struct
{
	BYTE* data;
	UINT32 data_length;
} xfCachedData;

typedef struct
{
	UINT32 localFormat;
	UINT32 formatToRequest;
	char* formatName;
} RequestedFormat;

typedef struct
{
	XSelectionEvent* expectedResponse;
	RequestedFormat* requestedFormat;
	BOOL data_raw_format;
} SelectionResponse;

struct xf_clipboard
{
	xfContext* xfc;
	rdpChannels* channels;
	CliprdrClientContext* context;

	wClipboard* system;

	Window root_window;
	Atom clipboard_atom;
	Atom property_atom;

	Atom timestamp_property_atom;
	Time selection_ownership_timestamp;

	Atom raw_transfer_atom;
	Atom raw_format_list_atom;

	UINT32 numClientFormats;
	xfCliprdrFormat clientFormats[20];

	UINT32 numServerFormats;
	CLIPRDR_FORMAT* serverFormats;

	size_t numTargets;
	Atom targets[20];

	UINT32 requestedFormatId;

	wHashTable* cachedData;
	wHashTable* cachedRawData;

	wArrayList* pending_responses;
	wArrayList* queued_responses;

	Window owner;
	BOOL sync;

	/* INCR mechanism */
	Atom incr_atom;
	BOOL incr_starts;
	BYTE* incr_data;
	size_t incr_data_length;
	long event_mask;

	/* XFixes extension */
	int xfixes_event_base;
	int xfixes_error_base;
	BOOL xfixes_supported;

	CliprdrFileContext* file;
	BOOL isImageContent;
};

static const char mime_text_plain[] = "text/plain";
static const char mime_uri_list[] = "text/uri-list";
static const char mime_html[] = "text/html";
static const char* mime_bitmap[] = { "image/bmp", "image/x-bmp", "image/x-MS-bmp",
	                                 "image/x-win-bitmap" };
static const char mime_webp[] = "image/webp";
static const char mime_png[] = "image/png";
static const char mime_jpeg[] = "image/jpeg";
static const char mime_tiff[] = "image/tiff";
static const char* mime_images[] = { mime_webp, mime_png, mime_jpeg, mime_tiff };

static const char mime_gnome_copied_files[] = "x-special/gnome-copied-files";
static const char mime_mate_copied_files[] = "x-special/mate-copied-files";

static const char type_FileGroupDescriptorW[] = "FileGroupDescriptorW";
static const char type_HtmlFormat[] = "HTML Format";

static void xf_cliprdr_clear_cached_data(xfClipboard* clipboard);
static UINT xf_cliprdr_send_client_format_list(xfClipboard* clipboard);
static void xf_cliprdr_set_selection_owner(xfContext* xfc, xfClipboard* clipboard, Time timestamp);

static void requested_format_free(RequestedFormat** ppRequestedFormat)
{
	if (!ppRequestedFormat)
		return;
	if (!(*ppRequestedFormat))
		return;

	free((*ppRequestedFormat)->formatName);
	free(*ppRequestedFormat);
	*ppRequestedFormat = nullptr;
}

static BOOL requested_format_replace(RequestedFormat** ppRequestedFormat, UINT32 remoteFormatId,
                                     UINT32 localFormatId, const char* formatName)
{
	if (!ppRequestedFormat)
		return FALSE;

	requested_format_free(ppRequestedFormat);
	RequestedFormat* requested = calloc(1, sizeof(RequestedFormat));
	if (!requested)
		return FALSE;
	requested->localFormat = localFormatId;
	requested->formatToRequest = remoteFormatId;
	if (formatName)
	{
		requested->formatName = _strdup(formatName);
		if (!requested->formatName)
		{
			free(requested);
			return FALSE;
		}
	}

	*ppRequestedFormat = requested;
	return TRUE;
}

static void selection_response_free(void* ptr)
{
	SelectionResponse* selection_response = (SelectionResponse*)ptr;
	if (!selection_response)
		return;

	free(selection_response->expectedResponse);
	requested_format_free(&selection_response->requestedFormat);
	free(selection_response);
}

static void xf_cached_data_free(void* ptr)
{
	xfCachedData* cached_data = ptr;
	if (!cached_data)
		return;

	free(cached_data->data);
	free(cached_data);
}

static xfCachedData* xf_cached_data_new(BYTE* data, size_t data_length)
{
	if (data_length > UINT32_MAX)
		return nullptr;

	xfCachedData* cached_data = calloc(1, sizeof(xfCachedData));
	if (!cached_data)
		return nullptr;

	cached_data->data = data;
	cached_data->data_length = (UINT32)data_length;

	return cached_data;
}

static xfCachedData* xf_cached_data_new_copy(const BYTE* data, size_t data_length)
{
	BYTE* copy = nullptr;
	if (data_length > 0)
	{
		copy = calloc(data_length + 1, sizeof(BYTE));
		if (!copy)
			return nullptr;
		memcpy(copy, data, data_length);
	}

	xfCachedData* cache = xf_cached_data_new(copy, data_length);
	if (!cache)
		free(copy);
	return cache;
}

static void xf_clipboard_free_server_formats(xfClipboard* clipboard)
{
	WINPR_ASSERT(clipboard);
	if (clipboard->serverFormats)
	{
		for (size_t i = 0; i < clipboard->numServerFormats; i++)
		{
			CLIPRDR_FORMAT* format = &clipboard->serverFormats[i];
			free(format->formatName);
		}

		free(clipboard->serverFormats);
		clipboard->serverFormats = nullptr;
	}
}

static BOOL xf_cliprdr_update_owner(xfClipboard* clipboard)
{
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	if (!clipboard->sync)
		return FALSE;

	Window owner = LogDynAndXGetSelectionOwner(xfc->log, xfc->display, clipboard->clipboard_atom);
	if (clipboard->owner == owner)
		return FALSE;

	clipboard->owner = owner;
	return TRUE;
}

static void xf_cliprdr_check_owner(xfClipboard* clipboard)
{
	if (xf_cliprdr_update_owner(clipboard))
		xf_cliprdr_send_client_format_list(clipboard);
}

static BOOL xf_cliprdr_is_self_owned(xfClipboard* clipboard)
{
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);
	return LogDynAndXGetSelectionOwner(xfc->log, xfc->display, clipboard->clipboard_atom) ==
	       xfc->drawable;
}

static void xf_cliprdr_set_raw_transfer_enabled(xfClipboard* clipboard, BOOL enabled)
{
	UINT32 data = WINPR_ASSERTING_INT_CAST(uint32_t, enabled);
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);
	LogDynAndXChangeProperty(xfc->log, xfc->display, xfc->drawable, clipboard->raw_transfer_atom,
	                         XA_INTEGER, 32, PropModeReplace, (const BYTE*)&data, 1);
}

static BOOL xf_cliprdr_is_raw_transfer_available(xfClipboard* clipboard)
{
	Atom type = 0;
	int format = 0;
	int result = 0;
	unsigned long length = 0;
	unsigned long bytes_left = 0;
	UINT32* data = nullptr;
	UINT32 is_enabled = 0;
	Window owner = None;
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	owner = LogDynAndXGetSelectionOwner(xfc->log, xfc->display, clipboard->clipboard_atom);

	if (owner != None)
	{
		result = LogDynAndXGetWindowProperty(xfc->log, xfc->display, owner,
		                                     clipboard->raw_transfer_atom, 0, 4, 0, XA_INTEGER,
		                                     &type, &format, &length, &bytes_left, (BYTE**)&data);
	}

	if (data)
	{
		is_enabled = *data;
		XFree(data);
	}

	if ((owner == None) || (owner == xfc->drawable))
		return FALSE;

	if (result != Success)
		return FALSE;

	return is_enabled != 0;
}

static BOOL xf_cliprdr_formats_equal(const CLIPRDR_FORMAT* server, const xfCliprdrFormat* client)
{
	WINPR_ASSERT(server);
	WINPR_ASSERT(client);

	if (server->formatName && client->formatName)
	{
		/* The server may be using short format names while we store them in full form. */
		return (0 == strncmp(server->formatName, client->formatName, strlen(server->formatName)));
	}

	if (!server->formatName && !client->formatName)
	{
		return (server->formatId == client->formatToRequest);
	}

	return FALSE;
}

static const xfCliprdrFormat* xf_cliprdr_get_client_format_by_id(xfClipboard* clipboard,
                                                                 UINT32 formatId)
{
	WINPR_ASSERT(clipboard);

	const BOOL formatIsHtml = formatId == ClipboardGetFormatId(clipboard->system, type_HtmlFormat);
	const BOOL fetchImage = clipboard->isImageContent && formatIsHtml;
	for (size_t index = 0; index < clipboard->numClientFormats; index++)
	{
		const xfCliprdrFormat* format = &(clipboard->clientFormats[index]);

		if (fetchImage && format->isImage)
			return format;

		if (format->formatToRequest == formatId)
			return format;
	}

	return nullptr;
}

static const xfCliprdrFormat* xf_cliprdr_get_client_format_by_atom(xfClipboard* clipboard,
                                                                   Atom atom)
{
	WINPR_ASSERT(clipboard);

	for (UINT32 i = 0; i < clipboard->numClientFormats; i++)
	{
		const xfCliprdrFormat* format = &(clipboard->clientFormats[i]);

		if (format->atom == atom)
			return format;
	}

	return nullptr;
}

static const CLIPRDR_FORMAT* xf_cliprdr_get_server_format_by_atom(xfClipboard* clipboard, Atom atom)
{
	WINPR_ASSERT(clipboard);

	for (size_t i = 0; i < clipboard->numClientFormats; i++)
	{
		const xfCliprdrFormat* client_format = &(clipboard->clientFormats[i]);

		if (client_format->atom == atom)
		{
			for (size_t j = 0; j < clipboard->numServerFormats; j++)
			{
				const CLIPRDR_FORMAT* server_format = &(clipboard->serverFormats[j]);

				if (xf_cliprdr_formats_equal(server_format, client_format))
					return server_format;
			}
		}
	}

	return nullptr;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_send_data_request(xfClipboard* clipboard, UINT32 formatId,
                                         WINPR_ATTR_UNUSED const xfCliprdrFormat* cformat)
{
	CLIPRDR_FORMAT_DATA_REQUEST request = WINPR_C_ARRAY_INIT;
	request.requestedFormatId = formatId;

	DEBUG_CLIPRDR("requesting format 0x%08" PRIx32 " [%s] {local 0x%08" PRIx32 "} [%s]", formatId,
	              ClipboardGetFormatIdString(formatId), cformat->localFormat, cformat->formatName);

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(clipboard->context);
	WINPR_ASSERT(clipboard->context->ClientFormatDataRequest);
	return clipboard->context->ClientFormatDataRequest(clipboard->context, &request);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_send_data_response(xfClipboard* clipboard, const xfCliprdrFormat* format,
                                          const BYTE* data, size_t size)
{
	CLIPRDR_FORMAT_DATA_RESPONSE response = WINPR_C_ARRAY_INIT;

	WINPR_ASSERT(clipboard);

	/* No request currently pending, do not send a response. */
	if (clipboard->requestedFormatId == UINT32_MAX)
		return CHANNEL_RC_OK;

	if (size == 0)
	{
		if (format)
			DEBUG_CLIPRDR("send CB_RESPONSE_FAIL response {format 0x%08" PRIx32
			              " [%s] {local 0x%08" PRIx32 "} [%s]",
			              format->formatToRequest,
			              ClipboardGetFormatIdString(format->formatToRequest), format->localFormat,
			              format->formatName);
		else
			DEBUG_CLIPRDR("send CB_RESPONSE_FAIL response");
	}
	else
	{
		WINPR_ASSERT(format);
		DEBUG_CLIPRDR("send response format 0x%08" PRIx32 " [%s] {local 0x%08" PRIx32 " [%s]} [%s]",
		              format->formatToRequest, ClipboardGetFormatIdString(format->formatToRequest),
		              format->localFormat,
		              ClipboardGetFormatName(clipboard->system, format->localFormat),
		              format->formatName);
	}
	/* Request handled, reset to invalid */
	clipboard->requestedFormatId = UINT32_MAX;

	response.common.msgFlags = (data) ? CB_RESPONSE_OK : CB_RESPONSE_FAIL;

	WINPR_ASSERT(size <= UINT32_MAX);
	response.common.dataLen = (UINT32)size;
	response.requestedFormatData = data;

	WINPR_ASSERT(clipboard->context);
	WINPR_ASSERT(clipboard->context->ClientFormatDataResponse);
	return clipboard->context->ClientFormatDataResponse(clipboard->context, &response);
}

static wStream* xf_cliprdr_serialize_server_format_list(xfClipboard* clipboard)
{
	UINT32 formatCount = 0;
	wStream* s = nullptr;

	WINPR_ASSERT(clipboard);

	/* Typical MS Word format list is about 80 bytes long. */
	if (!(s = Stream_New(nullptr, 128)))
	{
		WLog_ERR(TAG, "failed to allocate serialized format list");
		goto error;
	}

	/* If present, the last format is always synthetic CF_RAW. Do not include it. */
	formatCount = (clipboard->numServerFormats > 0) ? clipboard->numServerFormats - 1 : 0;
	Stream_Write_UINT32(s, formatCount);

	for (UINT32 i = 0; i < formatCount; i++)
	{
		CLIPRDR_FORMAT* format = &clipboard->serverFormats[i];
		size_t name_length = format->formatName ? strlen(format->formatName) : 0;

		DEBUG_CLIPRDR("server announced 0x%08" PRIx32 " [%s][%s]", format->formatId,
		              ClipboardGetFormatIdString(format->formatId), format->formatName);
		if (!Stream_EnsureRemainingCapacity(s, sizeof(UINT32) + name_length + 1))
		{
			WLog_ERR(TAG, "failed to expand serialized format list");
			goto error;
		}

		Stream_Write_UINT32(s, format->formatId);

		if (format->formatName)
			Stream_Write(s, format->formatName, name_length);

		Stream_Write_UINT8(s, '\0');
	}

	Stream_SealLength(s);
	return s;
error:
	Stream_Free(s, TRUE);
	return nullptr;
}

static CLIPRDR_FORMAT* xf_cliprdr_parse_server_format_list(BYTE* data, size_t length,
                                                           UINT32* numFormats)
{
	wStream* s = nullptr;
	CLIPRDR_FORMAT* formats = nullptr;

	WINPR_ASSERT(data || (length == 0));
	WINPR_ASSERT(numFormats);

	if (!(s = Stream_New(data, length)))
	{
		WLog_ERR(TAG, "failed to allocate stream for parsing serialized format list");
		goto error;
	}

	if (!Stream_CheckAndLogRequiredLength(TAG, s, sizeof(UINT32)))
		goto error;

	Stream_Read_UINT32(s, *numFormats);

	if (*numFormats > MAX_CLIPBOARD_FORMATS)
	{
		WLog_ERR(TAG, "unexpectedly large number of formats: %" PRIu32 "", *numFormats);
		goto error;
	}

	if (!(formats = (CLIPRDR_FORMAT*)calloc(*numFormats, sizeof(CLIPRDR_FORMAT))))
	{
		WLog_ERR(TAG, "failed to allocate format list");
		goto error;
	}

	for (UINT32 i = 0; i < *numFormats; i++)
	{
		const char* formatName = nullptr;
		size_t formatNameLength = 0;

		if (!Stream_CheckAndLogRequiredLength(TAG, s, sizeof(UINT32)))
			goto error;

		Stream_Read_UINT32(s, formats[i].formatId);
		formatName = (const char*)Stream_Pointer(s);
		formatNameLength = strnlen(formatName, Stream_GetRemainingLength(s));

		if (formatNameLength == Stream_GetRemainingLength(s))
		{
			WLog_ERR(TAG, "missing terminating null byte, %" PRIuz " bytes left to read",
			         formatNameLength);
			goto error;
		}

		formats[i].formatName = strndup(formatName, formatNameLength);
		Stream_Seek(s, formatNameLength + 1);
	}

	Stream_Free(s, FALSE);
	return formats;
error:
	Stream_Free(s, FALSE);
	free(formats);
	*numFormats = 0;
	return nullptr;
}

static void xf_cliprdr_free_formats(CLIPRDR_FORMAT* formats, UINT32 numFormats)
{
	WINPR_ASSERT(formats || (numFormats == 0));

	for (UINT32 i = 0; i < numFormats; i++)
	{
		free(formats[i].formatName);
	}

	free(formats);
}

static CLIPRDR_FORMAT* xf_cliprdr_get_raw_server_formats(xfClipboard* clipboard, UINT32* numFormats)
{
	Atom type = None;
	int format = 0;
	unsigned long length = 0;
	unsigned long remaining = 0;
	BYTE* data = nullptr;
	CLIPRDR_FORMAT* formats = nullptr;
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(numFormats);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	*numFormats = 0;

	Window owner = LogDynAndXGetSelectionOwner(xfc->log, xfc->display, clipboard->clipboard_atom);
	LogDynAndXGetWindowProperty(xfc->log, xfc->display, owner, clipboard->raw_format_list_atom, 0,
	                            4096, False, clipboard->raw_format_list_atom, &type, &format,
	                            &length, &remaining, &data);

	if (data && length > 0 && format == 8 && type == clipboard->raw_format_list_atom)
	{
		formats = xf_cliprdr_parse_server_format_list(data, length, numFormats);
	}
	else
	{
		WLog_ERR(TAG,
		         "failed to retrieve raw format list: data=%p, length=%lu, format=%d, type=%lu "
		         "(expected=%lu)",
		         (void*)data, length, format, (unsigned long)type,
		         (unsigned long)clipboard->raw_format_list_atom);
	}

	if (data)
		XFree(data);

	return formats;
}

static BOOL xf_cliprdr_should_add_format(const CLIPRDR_FORMAT* formats, size_t count,
                                         const xfCliprdrFormat* xformat)
{
	WINPR_ASSERT(formats);

	if (!xformat)
		return FALSE;

	for (size_t x = 0; x < count; x++)
	{
		const CLIPRDR_FORMAT* format = &formats[x];
		if (format->formatId == xformat->formatToRequest)
			return FALSE;
	}
	return TRUE;
}

static CLIPRDR_FORMAT* xf_cliprdr_get_formats_from_targets(xfClipboard* clipboard,
                                                           UINT32* numFormats)
{
	Atom atom = None;
	BYTE* data = nullptr;
	int format_property = 0;
	unsigned long proplength = 0;
	unsigned long bytes_left = 0;
	CLIPRDR_FORMAT* formats = nullptr;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(numFormats);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	*numFormats = 0;
	LogDynAndXGetWindowProperty(xfc->log, xfc->display, xfc->drawable, clipboard->property_atom, 0,
	                            200, 0, XA_ATOM, &atom, &format_property, &proplength, &bytes_left,
	                            &data);

	if (proplength > 0)
	{
		unsigned long length = proplength + 1;
		if (!data)
		{
			WLog_ERR(TAG, "XGetWindowProperty set length = %lu but data is nullptr", length);
			goto out;
		}

		if (!(formats = (CLIPRDR_FORMAT*)calloc(length, sizeof(CLIPRDR_FORMAT))))
		{
			WLog_ERR(TAG, "failed to allocate %lu CLIPRDR_FORMAT structs", length);
			goto out;
		}
	}

	{
		BOOL isImage = FALSE;
		BOOL hasHtml = FALSE;
		const uint32_t htmlFormatId = ClipboardRegisterFormat(clipboard->system, type_HtmlFormat);
		for (unsigned long i = 0; i < proplength; i++)
		{
			Atom tatom = ((Atom*)data)[i];
			const xfCliprdrFormat* format = xf_cliprdr_get_client_format_by_atom(clipboard, tatom);

			if (xf_cliprdr_should_add_format(formats, *numFormats, format))
			{
				CLIPRDR_FORMAT* cformat = &formats[*numFormats];
				cformat->formatId = format->formatToRequest;

				/* We do not want to double register a format, so check if HTML was already
				 * registered.
				 */
				if (cformat->formatId == htmlFormatId)
					hasHtml = TRUE;

				/* These are standard image types that will always be registered regardless of
				 * actual image format. */
				if (cformat->formatId == CF_TIFF)
					isImage = TRUE;
				else if (cformat->formatId == CF_DIB)
					isImage = TRUE;
				else if (cformat->formatId == CF_DIBV5)
					isImage = TRUE;

				if (format->formatName)
				{
					cformat->formatName = _strdup(format->formatName);
					WINPR_ASSERT(cformat->formatName);
				}
				else
					cformat->formatName = nullptr;

				*numFormats += 1;
			}
		}

		clipboard->isImageContent = isImage;
		if (isImage && !hasHtml)
		{
			CLIPRDR_FORMAT* cformat = &formats[*numFormats];
			cformat->formatId = htmlFormatId;
			cformat->formatName = _strdup(type_HtmlFormat);

			*numFormats += 1;
		}
	}
out:

	if (data)
		XFree(data);

	return formats;
}

static CLIPRDR_FORMAT* xf_cliprdr_get_client_formats(xfClipboard* clipboard, UINT32* numFormats)
{
	CLIPRDR_FORMAT* formats = nullptr;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(numFormats);

	*numFormats = 0;

	if (xf_cliprdr_is_raw_transfer_available(clipboard))
	{
		formats = xf_cliprdr_get_raw_server_formats(clipboard, numFormats);
	}

	if (*numFormats == 0)
	{
		xf_cliprdr_free_formats(formats, *numFormats);
		formats = xf_cliprdr_get_formats_from_targets(clipboard, numFormats);
	}

	return formats;
}

static void xf_cliprdr_provide_server_format_list(xfClipboard* clipboard)
{
	wStream* formats = nullptr;
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	formats = xf_cliprdr_serialize_server_format_list(clipboard);

	if (formats)
	{
		const size_t len = Stream_Length(formats);
		WINPR_ASSERT(len <= INT32_MAX);
		LogDynAndXChangeProperty(xfc->log, xfc->display, xfc->drawable,
		                         clipboard->raw_format_list_atom, clipboard->raw_format_list_atom,
		                         8, PropModeReplace, Stream_Buffer(formats), (int)len);
	}
	else
	{
		LogDynAndXDeleteProperty(xfc->log, xfc->display, xfc->drawable,
		                         clipboard->raw_format_list_atom);
	}

	Stream_Free(formats, TRUE);
}

static UINT xf_cliprdr_send_format_list(xfClipboard* clipboard, const CLIPRDR_FORMAT* formats,
                                        UINT32 numFormats)
{
	union
	{
		const CLIPRDR_FORMAT* cpv;
		CLIPRDR_FORMAT* pv;
	} cnv = { .cpv = formats };
	const CLIPRDR_FORMAT_LIST formatList = { .common.msgFlags = 0,
		                                     .numFormats = numFormats,
		                                     .formats = cnv.pv,
		                                     .common.msgType = CB_FORMAT_LIST };
	UINT ret = 0;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(formats || (numFormats == 0));

#if defined(WITH_DEBUG_CLIPRDR)
	for (UINT32 x = 0; x < numFormats; x++)
	{
		const CLIPRDR_FORMAT* format = &formats[x];
		DEBUG_CLIPRDR("announcing format 0x%08" PRIx32 " [%s] [%s]", format->formatId,
		              ClipboardGetFormatIdString(format->formatId), format->formatName);
	}
#endif

	/* Ensure all pending requests are answered. */
	xf_cliprdr_send_data_response(clipboard, nullptr, nullptr, 0);

	xf_cliprdr_clear_cached_data(clipboard);

	ret = cliprdr_file_context_notify_new_client_format_list(clipboard->file);
	if (ret)
		return ret;

	WINPR_ASSERT(clipboard->context);
	WINPR_ASSERT(clipboard->context->ClientFormatList);
	return clipboard->context->ClientFormatList(clipboard->context, &formatList);
}

static void xf_cliprdr_get_requested_targets(xfClipboard* clipboard)
{
	UINT32 numFormats = 0;
	CLIPRDR_FORMAT* formats = xf_cliprdr_get_client_formats(clipboard, &numFormats);
	xf_cliprdr_send_format_list(clipboard, formats, numFormats);
	xf_cliprdr_free_formats(formats, numFormats);
}

static void xf_cliprdr_process_requested_data(xfClipboard* clipboard, BOOL hasData,
                                              const BYTE* data, size_t size)
{
	BOOL bSuccess = 0;
	UINT32 SrcSize = 0;
	UINT32 DstSize = 0;
	INT64 srcFormatId = -1;
	BYTE* pDstData = nullptr;
	const xfCliprdrFormat* format = nullptr;

	WINPR_ASSERT(clipboard);

	if (clipboard->incr_starts && hasData)
		return;

	/* Reset incr_data_length, as we've reached the end of a possible incremental update.
	 * this ensures on next event that the buffer is not reused. */
	clipboard->incr_data_length = 0;

	format = xf_cliprdr_get_client_format_by_id(clipboard, clipboard->requestedFormatId);

	if (!hasData || !data || !format)
	{
		xf_cliprdr_send_data_response(clipboard, format, nullptr, 0);
		return;
	}

	switch (format->formatToRequest)
	{
		case CF_RAW:
			srcFormatId = CF_RAW;
			break;

		case CF_TEXT:
		case CF_OEMTEXT:
		case CF_UNICODETEXT:
			srcFormatId = format->localFormat;
			break;

		default:
			srcFormatId = format->localFormat;
			break;
	}

	if (srcFormatId < 0)
	{
		xf_cliprdr_send_data_response(clipboard, format, nullptr, 0);
		return;
	}

	ClipboardLock(clipboard->system);
	SrcSize = (UINT32)size;
	bSuccess = ClipboardSetData(clipboard->system, (UINT32)srcFormatId, data, SrcSize);

	if (bSuccess)
	{
		DstSize = 0;
		pDstData =
		    (BYTE*)ClipboardGetData(clipboard->system, clipboard->requestedFormatId, &DstSize);
	}
	ClipboardUnlock(clipboard->system);

	if (!pDstData)
	{
		xf_cliprdr_send_data_response(clipboard, format, nullptr, 0);
		return;
	}

	/*
	 * File lists require a bit of postprocessing to convert them from WinPR's FILDESCRIPTOR
	 * format to CLIPRDR_FILELIST expected by the server.
	 *
	 * We check for "FileGroupDescriptorW" format being registered (i.e., nonzero) in order
	 * to not process CF_RAW as a file list in case WinPR does not support file transfers.
	 */
	ClipboardLock(clipboard->system);
	if (format->formatToRequest &&
	    (format->formatToRequest ==
	     ClipboardGetFormatId(clipboard->system, type_FileGroupDescriptorW)))
	{
		UINT error = NO_ERROR;
		FILEDESCRIPTORW* file_array = (FILEDESCRIPTORW*)pDstData;
		UINT32 file_count = DstSize / sizeof(FILEDESCRIPTORW);
		pDstData = nullptr;
		DstSize = 0;

		const UINT32 flags = cliprdr_file_context_remote_get_flags(clipboard->file);
		error = cliprdr_serialize_file_list_ex(flags, file_array, file_count, &pDstData, &DstSize);

		if (error)
			WLog_ERR(TAG, "failed to serialize CLIPRDR_FILELIST: 0x%08X", error);
		else
		{
			UINT32 formatId = ClipboardGetFormatId(clipboard->system, mime_uri_list);
			UINT32 url_size = 0;

			char* url = ClipboardGetData(clipboard->system, formatId, &url_size);
			cliprdr_file_context_update_client_data(clipboard->file, url, url_size);
			free(url);
		}

		free(file_array);
	}
	ClipboardUnlock(clipboard->system);

	xf_cliprdr_send_data_response(clipboard, format, pDstData, DstSize);
	free(pDstData);
}

static BOOL xf_restore_input_flags(xfClipboard* clipboard)
{
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	if (clipboard->event_mask != 0)
	{
		XSelectInput(xfc->display, xfc->drawable, clipboard->event_mask);
		clipboard->event_mask = 0;
	}
	return TRUE;
}

static BOOL append(xfClipboard* clipboard, const void* sdata, size_t length)
{
	WINPR_ASSERT(clipboard);

	const size_t size = length + clipboard->incr_data_length + 2;
	BYTE* data = realloc(clipboard->incr_data, size);
	if (!data)
		return FALSE;
	clipboard->incr_data = data;
	memcpy(&data[clipboard->incr_data_length], sdata, length);
	clipboard->incr_data_length += length;
	clipboard->incr_data[clipboard->incr_data_length + 0] = '\0';
	clipboard->incr_data[clipboard->incr_data_length + 1] = '\0';
	return TRUE;
}

static BOOL xf_cliprdr_stop_incr(xfClipboard* clipboard)
{
	clipboard->incr_starts = FALSE;
	clipboard->incr_data_length = 0;
	return xf_restore_input_flags(clipboard);
}

static BOOL xf_cliprdr_get_requested_data(xfClipboard* clipboard, Atom target)
{
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	const xfCliprdrFormat* format =
	    xf_cliprdr_get_client_format_by_id(clipboard, clipboard->requestedFormatId);

	if (!format || (format->atom != target))
	{
		xf_cliprdr_send_data_response(clipboard, format, nullptr, 0);
		return FALSE;
	}

	Atom type = 0;
	BOOL has_data = FALSE;
	int format_property = 0;
	unsigned long length = 0;
	unsigned long total_bytes = 0;
	BYTE* property_data = nullptr;
	const int rc = LogDynAndXGetWindowProperty(
	    xfc->log, xfc->display, xfc->drawable, clipboard->property_atom, 0, 0, False, target, &type,
	    &format_property, &length, &total_bytes, &property_data);
	if (property_data)
		XFree(property_data);
	if (rc != Success)
	{
		xf_cliprdr_send_data_response(clipboard, format, nullptr, 0);
		return FALSE;
	}

	size_t len = 0;

	/* No data, empty return */
	if ((total_bytes <= 0) && !clipboard->incr_starts)
	{
		xf_cliprdr_stop_incr(clipboard);
	}
	/* We have to read incremental updates */
	else if (type == clipboard->incr_atom)
	{
		xf_cliprdr_stop_incr(clipboard);
		clipboard->incr_starts = TRUE;
		has_data = TRUE; /* data will follow in PropertyNotify event */
	}
	else
	{
		BYTE* incremental_data = nullptr;
		unsigned long incremental_len = 0;

		/* Incremental updates completed, pass data */
		len = clipboard->incr_data_length;
		if (total_bytes <= 0)
		{
			xf_cliprdr_stop_incr(clipboard);
			has_data = TRUE;
		}
		/* Read incremental data batch */
		else if (LogDynAndXGetWindowProperty(
		             xfc->log, xfc->display, xfc->drawable, clipboard->property_atom, 0,
		             WINPR_ASSERTING_INT_CAST(int32_t, total_bytes), False, target, &type,
		             &format_property, &incremental_len, &length, &incremental_data) == Success)
		{
			has_data = append(clipboard, incremental_data, incremental_len);
			len = clipboard->incr_data_length;
		}

		if (incremental_data)
			XFree(incremental_data);
	}

	LogDynAndXDeleteProperty(xfc->log, xfc->display, xfc->drawable, clipboard->property_atom);
	xf_cliprdr_process_requested_data(clipboard, has_data, clipboard->incr_data, len);

	return TRUE;
}

static void xf_cliprdr_append_target(xfClipboard* clipboard, Atom target)
{
	WINPR_ASSERT(clipboard);

	if (clipboard->numTargets >= ARRAYSIZE(clipboard->targets))
		return;

	for (size_t i = 0; i < clipboard->numTargets; i++)
	{
		if (clipboard->targets[i] == target)
			return;
	}

	clipboard->targets[clipboard->numTargets++] = target;
}

static void xf_cliprdr_provide_targets(xfClipboard* clipboard, const XSelectionEvent* respond)
{
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	if (respond->property != None)
	{
		WINPR_ASSERT(clipboard->numTargets <= INT32_MAX);
		LogDynAndXChangeProperty(xfc->log, xfc->display, respond->requestor, respond->property,
		                         XA_ATOM, 32, PropModeReplace, (const BYTE*)clipboard->targets,
		                         (int)clipboard->numTargets);
	}
}

static void xf_cliprdr_provide_timestamp(xfClipboard* clipboard, const XSelectionEvent* respond)
{
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	if (respond->property != None)
	{
		LogDynAndXChangeProperty(xfc->log, xfc->display, respond->requestor, respond->property,
		                         XA_INTEGER, 32, PropModeReplace,
		                         (const BYTE*)&clipboard->selection_ownership_timestamp, 1);
	}
}

#define xf_cliprdr_provide_data(clipboard, respond, data, size) \
	xf_cliprdr_provide_data_((clipboard), (respond), (data), (size), __FILE__, __func__, __LINE__)
static void xf_cliprdr_provide_data_(xfClipboard* clipboard, const XSelectionEvent* respond,
                                     const BYTE* data, UINT32 size, const char* file,
                                     const char* fkt, size_t line)
{
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	if (respond->property != None)
	{
		LogDynAndXChangeProperty_ex(xfc->log, file, fkt, line, xfc->display, respond->requestor,
		                            respond->property, respond->target, 8, PropModeReplace, data,
		                            WINPR_ASSERTING_INT_CAST(int32_t, size));
	}
}

static void log_selection_event(xfContext* xfc, const XEvent* event)
{
	const DWORD level = WLOG_TRACE;
	static wLog* _log_cached_ptr = nullptr;
	if (!_log_cached_ptr)
		_log_cached_ptr = WLog_Get(TAG);
	if (WLog_IsLevelActive(_log_cached_ptr, level))
	{

		switch (event->type)
		{
			case SelectionClear:
			{
				const XSelectionClearEvent* xevent = &event->xselectionclear;
				char* selection =
				    Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->selection);
				WLog_Print(_log_cached_ptr, level, "got event %s [selection %s]",
				           x11_event_string(event->type), selection);
				XFree(selection);
			}
			break;
			case SelectionNotify:
			{
				const XSelectionEvent* xevent = &event->xselection;
				char* selection =
				    Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->selection);
				char* target = Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->target);
				char* property = Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->property);
				WLog_Print(_log_cached_ptr, level,
				           "got event %s [selection %s, target %s, property %s]",
				           x11_event_string(event->type), selection, target, property);
				XFree(selection);
				XFree(target);
				XFree(property);
			}
			break;
			case SelectionRequest:
			{
				const XSelectionRequestEvent* xevent = &event->xselectionrequest;
				char* selection =
				    Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->selection);
				char* target = Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->target);
				char* property = Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->property);
				WLog_Print(_log_cached_ptr, level,
				           "got event %s [selection %s, target %s, property %s]",
				           x11_event_string(event->type), selection, target, property);
				XFree(selection);
				XFree(target);
				XFree(property);
			}
			break;
			case PropertyNotify:
			{
				const XPropertyEvent* xevent = &event->xproperty;
				char* atom = Safe_XGetAtomName(_log_cached_ptr, xfc->display, xevent->atom);
				WLog_Print(_log_cached_ptr, level, "got event %s [atom %s]",
				           x11_event_string(event->type), atom);
				XFree(atom);
			}
			break;
			default:
				break;
		}
	}
}

static BOOL xf_cliprdr_process_selection_notify(xfClipboard* clipboard,
                                                const XSelectionEvent* xevent)
{
	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(xevent);

	if (xevent->target == clipboard->targets[1])
	{
		if (xevent->property == None)
		{
			xf_cliprdr_send_client_format_list(clipboard);
		}
		else
		{
			xf_cliprdr_get_requested_targets(clipboard);
		}

		return TRUE;
	}
	else
	{
		return xf_cliprdr_get_requested_data(clipboard, xevent->target);
	}
}

void xf_cliprdr_clear_cached_data(xfClipboard* clipboard)
{
	WINPR_ASSERT(clipboard);

	ClipboardLock(clipboard->system);
	ClipboardEmpty(clipboard->system);

	HashTable_Clear(clipboard->cachedData);
	HashTable_Clear(clipboard->cachedRawData);

	cliprdr_file_context_clear(clipboard->file);

	xf_cliprdr_stop_incr(clipboard);
	ClipboardUnlock(clipboard->system);
}

static void* format_to_cache_slot(UINT32 format)
{
	union
	{
		uintptr_t uptr;
		void* vptr;
	} cnv;
	cnv.uptr = 0x100000000ULL + format;
	return cnv.vptr;
}

static UINT32 get_dst_format_id_for_local_request(xfClipboard* clipboard,
                                                  const xfCliprdrFormat* format)
{
	UINT32 dstFormatId = 0;

	WINPR_ASSERT(format);

	if (!format->formatName)
		return format->localFormat;

	ClipboardLock(clipboard->system);
	if (strcmp(format->formatName, type_HtmlFormat) == 0)
		dstFormatId = ClipboardGetFormatId(clipboard->system, mime_html);
	ClipboardUnlock(clipboard->system);

	if (strcmp(format->formatName, type_FileGroupDescriptorW) == 0)
		dstFormatId = format->localFormat;

	return dstFormatId;
}

static void get_src_format_info_for_local_request(xfClipboard* clipboard,
                                                  const xfCliprdrFormat* format,
                                                  UINT32* srcFormatId, BOOL* nullTerminated)
{
	*srcFormatId = 0;
	*nullTerminated = FALSE;

	if (format->formatName)
	{
		ClipboardLock(clipboard->system);
		if (strcmp(format->formatName, type_HtmlFormat) == 0)
		{
			*srcFormatId = ClipboardGetFormatId(clipboard->system, type_HtmlFormat);
			*nullTerminated = TRUE;
		}
		else if (strcmp(format->formatName, type_FileGroupDescriptorW) == 0)
		{
			*srcFormatId = ClipboardGetFormatId(clipboard->system, type_FileGroupDescriptorW);
			*nullTerminated = TRUE;
		}
		ClipboardUnlock(clipboard->system);
	}
	else
	{
		*srcFormatId = format->formatToRequest;
		switch (format->formatToRequest)
		{
			case CF_TEXT:
			case CF_OEMTEXT:
			case CF_UNICODETEXT:
				*nullTerminated = TRUE;
				break;
			case CF_DIB:
				*srcFormatId = CF_DIB;
				break;
			case CF_TIFF:
				*srcFormatId = CF_TIFF;
				break;
			default:
				break;
		}
	}
}

static xfCachedData* convert_data_from_existing_raw_data(xfClipboard* clipboard,
                                                         xfCachedData* cached_raw_data,
                                                         UINT32 srcFormatId, BOOL nullTerminated,
                                                         UINT32 dstFormatId)
{
	UINT32 dst_size = 0;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(cached_raw_data);
	WINPR_ASSERT(cached_raw_data->data);

	ClipboardLock(clipboard->system);
	BOOL success = ClipboardSetData(clipboard->system, srcFormatId, cached_raw_data->data,
	                                cached_raw_data->data_length);
	if (!success)
	{
		WLog_WARN(TAG, "Failed to set clipboard data (formatId: %u, data: %p, data_length: %u)",
		          srcFormatId, WINPR_CXX_COMPAT_CAST(const void*, cached_raw_data->data),
		          cached_raw_data->data_length);
		ClipboardUnlock(clipboard->system);
		return nullptr;
	}

	BYTE* dst_data = ClipboardGetData(clipboard->system, dstFormatId, &dst_size);
	if (!dst_data)
	{
		WLog_WARN(TAG, "Failed to get converted clipboard data");
		ClipboardUnlock(clipboard->system);
		return nullptr;
	}
	ClipboardUnlock(clipboard->system);

	if (nullTerminated)
	{
		BYTE* nullTerminator = memchr(dst_data, '\0', dst_size);
		if (nullTerminator)
		{
			const intptr_t diff = nullTerminator - dst_data;
			WINPR_ASSERT(diff >= 0);
			WINPR_ASSERT(diff <= UINT32_MAX);
			dst_size = (UINT32)diff;
		}
	}

	xfCachedData* cached_data = xf_cached_data_new(dst_data, dst_size);
	if (!cached_data)
	{
		WLog_WARN(TAG, "Failed to allocate cache entry");
		free(dst_data);
		return nullptr;
	}

	if (!HashTable_Insert(clipboard->cachedData, format_to_cache_slot(dstFormatId), cached_data))
	{
		WLog_WARN(TAG, "Failed to cache clipboard data");
		xf_cached_data_free(cached_data);
		return nullptr;
	}

	return cached_data;
}

WINPR_ATTR_NODISCARD
static BOOL xf_cliprdr_pending_responses_ArrayList_ForEachFkt(void* data, size_t index, va_list ap)
{
	UINT32 formatId = 0;
	SelectionResponse* pendingResponse = (SelectionResponse*)data;
	UINT32 currentFormatId = va_arg(ap, UINT32);
	BOOL* res = va_arg(ap, BOOL*);

	WINPR_UNUSED(index);
	WINPR_UNUSED(ap);
	WINPR_ASSERT(res);

	formatId = pendingResponse->requestedFormat->formatToRequest;

	if (formatId != currentFormatId)
		*res = TRUE;
	return TRUE;
}

static void xf_cliprdr_provide_selection(xfClipboard* clipboard, XSelectionEvent* respond)
{
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	union
	{
		XEvent* ev;
		XSelectionEvent* sev;
	} conv;

	conv.sev = respond;
	LogDynAndXSendEvent(xfc->log, xfc->display, respond->requestor, 0, 0, conv.ev);
	LogDynAndXFlush(xfc->log, xfc->display);
}

static BOOL xf_cliprdr_process_selection_request(xfClipboard* clipboard,
                                                 const XSelectionRequestEvent* xevent)
{
	int fmt = 0;
	Atom type = 0;
	UINT32 formatId = 0;
	XSelectionEvent* respond = nullptr;
	BYTE* data = nullptr;
	BOOL delayRespond = 0;
	BOOL rawTransfer = 0;
	unsigned long length = 0;
	unsigned long bytes_left = 0;
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(xevent);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	if (xevent->owner != xfc->drawable)
		return FALSE;

	delayRespond = FALSE;

	if (!(respond = (XSelectionEvent*)calloc(1, sizeof(XSelectionEvent))))
	{
		WLog_ERR(TAG, "failed to allocate XEvent data");
		return FALSE;
	}

	respond->property = None;
	respond->type = SelectionNotify;
	respond->display = xevent->display;
	respond->requestor = xevent->requestor;
	respond->selection = xevent->selection;
	respond->target = xevent->target;
	respond->time = xevent->time;

	if (xevent->target == clipboard->targets[0]) /* TIMESTAMP */
	{
		/* Someone else requests the selection's timestamp */
		respond->property = xevent->property;
		xf_cliprdr_provide_timestamp(clipboard, respond);
	}
	else if (xevent->target == clipboard->targets[1]) /* TARGETS */
	{
		/* Someone else requests our available formats */
		respond->property = xevent->property;
		xf_cliprdr_provide_targets(clipboard, respond);
	}
	else
	{
		const CLIPRDR_FORMAT* format =
		    xf_cliprdr_get_server_format_by_atom(clipboard, xevent->target);
		const xfCliprdrFormat* cformat =
		    xf_cliprdr_get_client_format_by_atom(clipboard, xevent->target);

		if (format && (xevent->requestor != xfc->drawable))
		{
			formatId = format->formatId;
			rawTransfer = FALSE;
			xfCachedData* cached_data = nullptr;

			if (formatId == CF_RAW)
			{
				if (LogDynAndXGetWindowProperty(
				        xfc->log, xfc->display, xevent->requestor, clipboard->property_atom, 0, 4,
				        0, XA_INTEGER, &type, &fmt, &length, &bytes_left, &data) != Success)
				{
				}

				if (data)
				{
					rawTransfer = TRUE;
					CopyMemory(&formatId, data, 4);
					XFree(data);
				}
			}

			const UINT32 dstFormatId = get_dst_format_id_for_local_request(clipboard, cformat);
			DEBUG_CLIPRDR("formatId: 0x%08" PRIx32 ", dstFormatId: 0x%08" PRIx32 "", formatId,
			              dstFormatId);

			wHashTable* table = clipboard->cachedData;
			if (rawTransfer)
				table = clipboard->cachedRawData;

			HashTable_Lock(table);
			if (!rawTransfer)
				cached_data = HashTable_GetItemValue(table, format_to_cache_slot(dstFormatId));
			else
				cached_data = HashTable_GetItemValue(table, format_to_cache_slot(formatId));
			HashTable_Unlock(table);

			DEBUG_CLIPRDR("hasCachedData: %u, rawTransfer: %d", cached_data ? 1u : 0u, rawTransfer);

			if (!cached_data && !rawTransfer)
			{
				UINT32 srcFormatId = 0;
				BOOL nullTerminated = FALSE;
				xfCachedData* cached_raw_data = nullptr;

				get_src_format_info_for_local_request(clipboard, cformat, &srcFormatId,
				                                      &nullTerminated);

				HashTable_Lock(clipboard->cachedRawData);
				cached_raw_data =
				    HashTable_GetItemValue(clipboard->cachedRawData, (void*)(UINT_PTR)srcFormatId);
				HashTable_Unlock(clipboard->cachedRawData);

				DEBUG_CLIPRDR("hasCachedRawData: %u, rawDataLength: %u", cached_raw_data ? 1u : 0u,
				              cached_raw_data ? cached_raw_data->data_length : 0);

				if (cached_raw_data && cached_raw_data->data_length != 0)
					cached_data = convert_data_from_existing_raw_data(
					    clipboard, cached_raw_data, srcFormatId, nullTerminated, dstFormatId);
			}

			DEBUG_CLIPRDR("hasCachedData: %u", cached_data ? 1u : 0u);

			if (cached_data)
			{
				/* Cached clipboard data available. Send it now */
				respond->property = xevent->property;

				// NOLINTNEXTLINE(clang-analyzer-unix.Malloc)
				xf_cliprdr_provide_data(clipboard, respond, cached_data->data,
				                        cached_data->data_length);
			}
			else
			{
				SelectionResponse* selection_response = nullptr;
				WINPR_ASSERT(cformat);

				if (!(selection_response =
				          (SelectionResponse*)calloc(1, sizeof(SelectionResponse))))
				{
					respond->property = None;
					goto out;
				}
				respond->property = xevent->property;

				selection_response->expectedResponse = respond;
				requested_format_replace(&selection_response->requestedFormat, formatId,
				                         dstFormatId, cformat->formatName);
				selection_response->data_raw_format = rawTransfer;

				ArrayList_Lock(clipboard->pending_responses);
				ArrayList_Lock(clipboard->queued_responses);
				if (ArrayList_Count(clipboard->pending_responses) > 0)
				{
					BOOL shouldQueued = FALSE;
					BOOL success = FALSE;
					success = ArrayList_ForEach(clipboard->pending_responses,
					                            xf_cliprdr_pending_responses_ArrayList_ForEachFkt,
					                            formatId, &shouldQueued);
					if (!success || shouldQueued)
					{
						if (!ArrayList_Append(clipboard->queued_responses, selection_response))
						{
							requested_format_free(&selection_response->requestedFormat);
							free(selection_response);
							respond->property = None;
							goto out2;
						}
					}
					else
					{
						if (!ArrayList_Append(clipboard->pending_responses, selection_response))
						{
							requested_format_free(&selection_response->requestedFormat);
							free(selection_response);
							respond->property = None;
							goto out2;
						}
					}
				}
				else
				{
					if (!ArrayList_Append(clipboard->pending_responses, selection_response))
					{
						requested_format_free(&selection_response->requestedFormat);
						free(selection_response);
						respond->property = None;
						goto out2;
					}
					/**
					 * Send clipboard data request to the server.
					 * Response will be postponed after receiving the data
					 */
					// NOLINTNEXTLINE(clang-analyzer-unix.Malloc): HashTable_Insert takes ownership
					xf_cliprdr_send_data_request(clipboard, formatId, cformat);
				}
				delayRespond = TRUE;
			out2:
				ArrayList_Unlock(clipboard->queued_responses);
				ArrayList_Unlock(clipboard->pending_responses);
			}
		}
	}

out:
	if (!delayRespond)
	{
		xf_cliprdr_provide_selection(clipboard, respond);
		free(respond);
	}

	return TRUE;
}

static BOOL xf_cliprdr_process_selection_clear(xfClipboard* clipboard,
                                               const XSelectionClearEvent* xevent)
{
	xfContext* xfc = nullptr;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(xevent);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	WINPR_UNUSED(xevent);

	if (xf_cliprdr_is_self_owned(clipboard))
		return FALSE;

	LogDynAndXDeleteProperty(xfc->log, xfc->display, clipboard->root_window,
	                         clipboard->property_atom);
	return TRUE;
}

static BOOL xf_cliprdr_process_property_notify(xfClipboard* clipboard, const XPropertyEvent* xevent)
{
	const xfCliprdrFormat* format = nullptr;
	xfContext* xfc = nullptr;

	if (!clipboard)
		return TRUE;

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);
	WINPR_ASSERT(xevent);

	if (xevent->atom == clipboard->timestamp_property_atom)
	{
		/* This is the response to the property change we did
		 * in xf_cliprdr_prepare_to_set_selection_owner. Now
		 * we can set ourselves as the selection owner. (See
		 * comments in those functions below.) */
		xf_cliprdr_set_selection_owner(xfc, clipboard, xevent->time);
		return TRUE;
	}

	if (xevent->atom != clipboard->property_atom)
		return FALSE; /* Not cliprdr-related */

	if (xevent->window == clipboard->root_window)
	{
		xf_cliprdr_send_client_format_list(clipboard);
	}
	else if ((xevent->window == xfc->drawable) && (xevent->state == PropertyNewValue) &&
	         clipboard->incr_starts)
	{
		format = xf_cliprdr_get_client_format_by_id(clipboard, clipboard->requestedFormatId);

		if (format)
			xf_cliprdr_get_requested_data(clipboard, format->atom);
	}

	return TRUE;
}

void xf_cliprdr_handle_xevent(xfContext* xfc, const XEvent* event)
{
	xfClipboard* clipboard = nullptr;

	if (!xfc || !event)
		return;

	clipboard = xfc->clipboard;

	if (!clipboard)
		return;

#ifdef WITH_XFIXES

	if (clipboard->xfixes_supported &&
	    event->type == XFixesSelectionNotify + clipboard->xfixes_event_base)
	{
		const XFixesSelectionNotifyEvent* se = (const XFixesSelectionNotifyEvent*)event;

		if (se->subtype == XFixesSetSelectionOwnerNotify)
		{
			if (se->selection != clipboard->clipboard_atom)
				return;

			if (LogDynAndXGetSelectionOwner(xfc->log, xfc->display, se->selection) == xfc->drawable)
				return;

			clipboard->owner = None;
			xf_cliprdr_check_owner(clipboard);
		}

		return;
	}

#endif

	switch (event->type)
	{
		case SelectionNotify:
			log_selection_event(xfc, event);
			xf_cliprdr_process_selection_notify(clipboard, &event->xselection);
			break;

		case SelectionRequest:
			log_selection_event(xfc, event);
			xf_cliprdr_process_selection_request(clipboard, &event->xselectionrequest);
			break;

		case SelectionClear:
			log_selection_event(xfc, event);
			xf_cliprdr_process_selection_clear(clipboard, &event->xselectionclear);
			break;

		case PropertyNotify:
			log_selection_event(xfc, event);
			xf_cliprdr_process_property_notify(clipboard, &event->xproperty);
			break;

		case FocusIn:
			if (!clipboard->xfixes_supported)
			{
				xf_cliprdr_check_owner(clipboard);
			}

			break;
		default:
			break;
	}
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_send_client_capabilities(xfClipboard* clipboard)
{
	CLIPRDR_CAPABILITIES capabilities = WINPR_C_ARRAY_INIT;
	CLIPRDR_GENERAL_CAPABILITY_SET generalCapabilitySet = WINPR_C_ARRAY_INIT;

	WINPR_ASSERT(clipboard);

	capabilities.cCapabilitiesSets = 1;
	capabilities.capabilitySets = (CLIPRDR_CAPABILITY_SET*)&(generalCapabilitySet);
	generalCapabilitySet.capabilitySetType = CB_CAPSTYPE_GENERAL;
	generalCapabilitySet.capabilitySetLength = 12;
	generalCapabilitySet.version = CB_CAPS_VERSION_2;
	generalCapabilitySet.generalFlags = CB_USE_LONG_FORMAT_NAMES;

	WINPR_ASSERT(clipboard);
	generalCapabilitySet.generalFlags |= cliprdr_file_context_current_flags(clipboard->file);

	WINPR_ASSERT(clipboard->context);
	WINPR_ASSERT(clipboard->context->ClientCapabilities);
	return clipboard->context->ClientCapabilities(clipboard->context, &capabilities);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_send_client_format_list(xfClipboard* clipboard)
{
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	UINT32 numFormats = 0;
	CLIPRDR_FORMAT* formats = xf_cliprdr_get_client_formats(clipboard, &numFormats);

	const UINT ret = xf_cliprdr_send_format_list(clipboard, formats, numFormats);

	if (clipboard->owner && clipboard->owner != xfc->drawable)
	{
		/* Request the owner for TARGETS, and wait for SelectionNotify event */
		LogDynAndXConvertSelection(xfc->log, xfc->display, clipboard->clipboard_atom,
		                           clipboard->targets[1], clipboard->property_atom, xfc->drawable,
		                           CurrentTime);
	}

	xf_cliprdr_free_formats(formats, numFormats);

	return ret;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_send_client_format_list_response(xfClipboard* clipboard, BOOL status)
{
	CLIPRDR_FORMAT_LIST_RESPONSE formatListResponse = WINPR_C_ARRAY_INIT;

	formatListResponse.common.msgType = CB_FORMAT_LIST_RESPONSE;
	formatListResponse.common.msgFlags = status ? CB_RESPONSE_OK : CB_RESPONSE_FAIL;
	formatListResponse.common.dataLen = 0;

	WINPR_ASSERT(clipboard);
	WINPR_ASSERT(clipboard->context);
	WINPR_ASSERT(clipboard->context->ClientFormatListResponse);
	return clipboard->context->ClientFormatListResponse(clipboard->context, &formatListResponse);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_monitor_ready(CliprdrClientContext* context,
                                     const CLIPRDR_MONITOR_READY* monitorReady)
{
	WINPR_ASSERT(context);
	WINPR_ASSERT(monitorReady);

	xfClipboard* clipboard = cliprdr_file_context_get_context(context->custom);
	WINPR_ASSERT(clipboard);

	WINPR_UNUSED(monitorReady);

	const UINT ret = xf_cliprdr_send_client_capabilities(clipboard);
	if (ret != CHANNEL_RC_OK)
		return ret;

	const UINT ret2 = xf_cliprdr_send_client_format_list(clipboard);
	if (ret2 != CHANNEL_RC_OK)
		return ret2;

	clipboard->sync = TRUE;
	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_server_capabilities(CliprdrClientContext* context,
                                           const CLIPRDR_CAPABILITIES* capabilities)
{
	WINPR_ASSERT(context);
	WINPR_ASSERT(capabilities);

	xfClipboard* clipboard = cliprdr_file_context_get_context(context->custom);
	WINPR_ASSERT(clipboard);

	const BYTE* capsPtr = (const BYTE*)capabilities->capabilitySets;
	WINPR_ASSERT(capsPtr);

	if (!cliprdr_file_context_remote_set_flags(clipboard->file, 0))
		return ERROR_INTERNAL_ERROR;

	for (UINT32 i = 0; i < capabilities->cCapabilitiesSets; i++)
	{
		const CLIPRDR_CAPABILITY_SET* caps = (const CLIPRDR_CAPABILITY_SET*)capsPtr;

		if (caps->capabilitySetType == CB_CAPSTYPE_GENERAL)
		{
			const CLIPRDR_GENERAL_CAPABILITY_SET* generalCaps =
			    (const CLIPRDR_GENERAL_CAPABILITY_SET*)caps;

			if (!cliprdr_file_context_remote_set_flags(clipboard->file, generalCaps->generalFlags))
				return ERROR_INTERNAL_ERROR;
		}

		capsPtr += caps->capabilitySetLength;
	}

	return CHANNEL_RC_OK;
}

static void xf_cliprdr_prepare_to_set_selection_owner(xfContext* xfc, xfClipboard* clipboard)
{
	WINPR_ASSERT(xfc);
	WINPR_ASSERT(clipboard);
	/*
	 * When you're writing to the selection in response to a
	 * normal X event like a mouse click or keyboard action, you
	 * get the selection timestamp by copying the time field out
	 * of that X event. Here, we're doing it on our own
	 * initiative, so we have to _request_ the X server time.
	 *
	 * There isn't a GetServerTime request in the X protocol, so I
	 * work around it by setting a property on our own window, and
	 * waiting for a PropertyNotify event to come back telling me
	 * it's been done - which will have a timestamp we can use.
	 */

	/* We have to set the property to some value, but it doesn't
	 * matter what. Set it to its own name, which we have here
	 * anyway! */
	Atom value = clipboard->timestamp_property_atom;

	LogDynAndXChangeProperty(xfc->log, xfc->display, xfc->drawable,
	                         clipboard->timestamp_property_atom, XA_ATOM, 32, PropModeReplace,
	                         (const BYTE*)&value, 1);
	LogDynAndXFlush(xfc->log, xfc->display);
}

static void xf_cliprdr_set_selection_owner(xfContext* xfc, xfClipboard* clipboard, Time timestamp)
{
	WINPR_ASSERT(xfc);
	WINPR_ASSERT(clipboard);
	/*
	 * Actually set ourselves up as the selection owner, now that
	 * we have a timestamp to use.
	 */

	clipboard->selection_ownership_timestamp = timestamp;
	LogDynAndXSetSelectionOwner(xfc->log, xfc->display, clipboard->clipboard_atom, xfc->drawable,
	                            timestamp);
	LogDynAndXFlush(xfc->log, xfc->display);
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_server_format_list(CliprdrClientContext* context,
                                          const CLIPRDR_FORMAT_LIST* formatList)
{
	xfContext* xfc = nullptr;
	UINT ret = 0;
	xfClipboard* clipboard = nullptr;

	WINPR_ASSERT(context);
	WINPR_ASSERT(formatList);

	clipboard = cliprdr_file_context_get_context(context->custom);
	WINPR_ASSERT(clipboard);

	xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	xf_lock_x11(xfc);

	/* Clear the active SelectionRequest, as it is now invalid */
	ArrayList_Clear(clipboard->pending_responses);
	ArrayList_Clear(clipboard->queued_responses);

	xf_cliprdr_clear_cached_data(clipboard);

	xf_clipboard_free_server_formats(clipboard);

	clipboard->numServerFormats = formatList->numFormats + 1; /* +1 for CF_RAW */

	if (!(clipboard->serverFormats =
	          (CLIPRDR_FORMAT*)calloc(clipboard->numServerFormats, sizeof(CLIPRDR_FORMAT))))
	{
		WLog_ERR(TAG, "failed to allocate %" PRIu32 " CLIPRDR_FORMAT structs",
		         clipboard->numServerFormats);
		ret = CHANNEL_RC_NO_MEMORY;
		goto out;
	}

	for (size_t i = 0; i < formatList->numFormats; i++)
	{
		const CLIPRDR_FORMAT* format = &formatList->formats[i];
		CLIPRDR_FORMAT* srvFormat = &clipboard->serverFormats[i];

		srvFormat->formatId = format->formatId;

		if (format->formatName)
		{
			srvFormat->formatName = _strdup(format->formatName);

			if (!srvFormat->formatName)
			{
				for (UINT32 k = 0; k < i; k++)
					free(clipboard->serverFormats[k].formatName);

				clipboard->numServerFormats = 0;
				free(clipboard->serverFormats);
				clipboard->serverFormats = nullptr;
				ret = CHANNEL_RC_NO_MEMORY;
				goto out;
			}
		}
	}

	ClipboardLock(clipboard->system);
	ret = cliprdr_file_context_notify_new_server_format_list(clipboard->file);
	ClipboardUnlock(clipboard->system);
	if (ret)
		goto out;

	/* CF_RAW is always implicitly supported by the server */
	{
		CLIPRDR_FORMAT* format = &clipboard->serverFormats[formatList->numFormats];
		format->formatId = CF_RAW;
		format->formatName = nullptr;
	}
	xf_cliprdr_provide_server_format_list(clipboard);
	clipboard->numTargets = 2;

	for (size_t i = 0; i < formatList->numFormats; i++)
	{
		const CLIPRDR_FORMAT* format = &formatList->formats[i];

		for (size_t j = 0; j < clipboard->numClientFormats; j++)
		{
			const xfCliprdrFormat* clientFormat = &clipboard->clientFormats[j];
			if (xf_cliprdr_formats_equal(format, clientFormat))
			{
				if ((clientFormat->formatName != nullptr) &&
				    (strcmp(type_FileGroupDescriptorW, clientFormat->formatName) == 0))
				{
					if (!cliprdr_file_context_has_local_support(clipboard->file))
						continue;
				}
				xf_cliprdr_append_target(clipboard, clientFormat->atom);
			}
		}
	}

	ret = xf_cliprdr_send_client_format_list_response(clipboard, TRUE);
	if (xfc->remote_app)
		xf_cliprdr_set_selection_owner(xfc, clipboard, CurrentTime);
	else
		xf_cliprdr_prepare_to_set_selection_owner(xfc, clipboard);

out:
	xf_unlock_x11(xfc);

	return ret;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT xf_cliprdr_server_format_list_response(
    WINPR_ATTR_UNUSED CliprdrClientContext* context,
    WINPR_ATTR_UNUSED const CLIPRDR_FORMAT_LIST_RESPONSE* formatListResponse)
{
	WINPR_ASSERT(context);
	WINPR_ASSERT(formatListResponse);
	// xfClipboard* clipboard = (xfClipboard*) context->custom;
	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT
xf_cliprdr_server_format_data_request(CliprdrClientContext* context,
                                      const CLIPRDR_FORMAT_DATA_REQUEST* formatDataRequest)
{
	const xfCliprdrFormat* format = nullptr;

	WINPR_ASSERT(context);
	WINPR_ASSERT(formatDataRequest);

	xfClipboard* clipboard = cliprdr_file_context_get_context(context->custom);
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	const uint32_t formatId = formatDataRequest->requestedFormatId;

	const BOOL rawTransfer = xf_cliprdr_is_raw_transfer_available(clipboard);

	if (rawTransfer)
	{
		format = xf_cliprdr_get_client_format_by_id(clipboard, CF_RAW);
		LogDynAndXChangeProperty(xfc->log, xfc->display, xfc->drawable, clipboard->property_atom,
		                         XA_INTEGER, 32, PropModeReplace, (const BYTE*)&formatId, 1);
	}
	else
		format = xf_cliprdr_get_client_format_by_id(clipboard, formatId);

	clipboard->requestedFormatId = rawTransfer ? CF_RAW : formatId;
	if (!format)
		return xf_cliprdr_send_data_response(clipboard, format, nullptr, 0);

	DEBUG_CLIPRDR("requested format 0x%08" PRIx32 " [%s] {local 0x%08" PRIx32 " [%s]} [%s]",
	              format->formatToRequest, ClipboardGetFormatIdString(format->formatToRequest),
	              format->localFormat,
	              ClipboardGetFormatName(clipboard->system, format->localFormat),
	              format->formatName);
	LogDynAndXConvertSelection(xfc->log, xfc->display, clipboard->clipboard_atom, format->atom,
	                           clipboard->property_atom, xfc->drawable, CurrentTime);
	LogDynAndXFlush(xfc->log, xfc->display);
	/* After this point, we expect a SelectionNotify event from the clipboard owner. */
	return CHANNEL_RC_OK;
}

/**
 * Function description
 *
 * @return 0 on success, otherwise a Win32 error code
 */
static UINT
xf_cliprdr_server_format_data_response(CliprdrClientContext* context,
                                       const CLIPRDR_FORMAT_DATA_RESPONSE* formatDataResponse)
{
	BOOL bSuccess = FALSE;
	BOOL bRawCached = FALSE;
	BOOL bFileContextUpdated = FALSE;

	WINPR_ASSERT(context);
	WINPR_ASSERT(formatDataResponse);

	xfClipboard* clipboard = cliprdr_file_context_get_context(context->custom);
	WINPR_ASSERT(clipboard);

	xfContext* xfc = clipboard->xfc;
	WINPR_ASSERT(xfc);

	const UINT32 size = formatDataResponse->common.dataLen;
	const BYTE* data = formatDataResponse->requestedFormatData;

	// Keep the same lock order as process_selection_request to prevent deadlock
	xf_lock_x11(xfc);
	ArrayList_Lock(clipboard->pending_responses);
	ArrayList_Lock(clipboard->queued_responses);
	if (formatDataResponse->common.msgFlags == CB_RESPONSE_FAIL)
	{
		WLog_WARN(TAG, "Format Data Response PDU msgFlags is CB_RESPONSE_FAIL");
		while (ArrayList_Count(clipboard->pending_responses) > 0)
		{
			SelectionResponse* pending = ArrayList_GetItem(clipboard->pending_responses, 0);

			pending->expectedResponse->property = None;
			xf_cliprdr_provide_selection(clipboard, pending->expectedResponse);

			ArrayList_Remove(clipboard->pending_responses, pending);
		}
		WINPR_ASSERT(ArrayList_Count(clipboard->pending_responses) == 0);
	}

	while (ArrayList_Count(clipboard->pending_responses) > 0)
	{
		BYTE* pDstData = nullptr;
		UINT32 DstSize = 0;
		UINT32 SrcSize = 0;
		UINT32 srcFormatId = 0;
		UINT32 dstFormatId = 0;
		BOOL nullTerminated = FALSE;
		xfCachedData* cached_data = nullptr;
		xfCachedData* hit_cached_data = nullptr;

		SelectionResponse* pending = ArrayList_GetItem(clipboard->pending_responses, 0);
		const RequestedFormat* format = pending->requestedFormat;
		if (pending->data_raw_format)
		{
			srcFormatId = CF_RAW;
			dstFormatId = CF_RAW;
		}
		else if (!format)
		{
			pending->expectedResponse->property = None;
			goto out;
		}
		else if (format->formatName)
		{
			dstFormatId = format->localFormat;

			ClipboardLock(clipboard->system);
			if (strcmp(format->formatName, type_HtmlFormat) == 0)
			{
				srcFormatId = ClipboardGetFormatId(clipboard->system, type_HtmlFormat);
				dstFormatId = ClipboardGetFormatId(clipboard->system, mime_html);
				nullTerminated = TRUE;
			}

			if (strcmp(format->formatName, type_FileGroupDescriptorW) == 0)
			{
				if (!bFileContextUpdated)
				{
					if (!cliprdr_file_context_update_server_data(clipboard->file, clipboard->system,
					                                             data, size))
						WLog_WARN(TAG, "failed to update file descriptors");
					else
						bFileContextUpdated = TRUE;
				}

				srcFormatId = ClipboardGetFormatId(clipboard->system, type_FileGroupDescriptorW);
				const xfCliprdrFormat* dstTargetFormat = xf_cliprdr_get_client_format_by_atom(
				    clipboard, pending->expectedResponse->target);
				if (!dstTargetFormat)
				{
					dstFormatId = ClipboardGetFormatId(clipboard->system, mime_uri_list);
				}
				else
				{
					dstFormatId = dstTargetFormat->localFormat;
				}

				nullTerminated = TRUE;
			}
			ClipboardUnlock(clipboard->system);
		}
		else
		{
			srcFormatId = format->formatToRequest;
			dstFormatId = format->localFormat;
			switch (format->formatToRequest)
			{
				case CF_TEXT:
					nullTerminated = TRUE;
					break;

				case CF_OEMTEXT:
					nullTerminated = TRUE;
					break;

				case CF_UNICODETEXT:
					nullTerminated = TRUE;
					break;

				case CF_DIB:
					srcFormatId = CF_DIB;
					break;

				case CF_TIFF:
					srcFormatId = CF_TIFF;
					break;

				default:
					break;
			}
		}

		DEBUG_CLIPRDR("requested format 0x%08" PRIx32 " [%s] {local 0x%08" PRIx32 " [%s]} [%s]",
		              format->formatToRequest, ClipboardGetFormatIdString(format->formatToRequest),
		              format->localFormat,
		              ClipboardGetFormatName(clipboard->system, format->localFormat),
		              format->formatName);
		SrcSize = size;

		DEBUG_CLIPRDR("srcFormatId: 0x%08" PRIx32 ", dstFormatId: 0x%08" PRIx32 "", srcFormatId,
		              dstFormatId);

		if (SrcSize != 0 && !bRawCached)
		{
			/* We have to copy the original data again, as pSrcData is now owned
			 * by clipboard->system. Memory allocation failure is not fatal here
			 * as this is only a cached value. */
			{
				// clipboard->cachedData owns cached_data
				// NOLINTNEXTLINE(clang-analyzer-unix.Malloc
				xfCachedData* cached_raw_data = xf_cached_data_new_copy(data, size);
				if (!cached_raw_data)
					WLog_WARN(TAG, "Failed to allocate cache entry");
				else
				{
					if (!(bRawCached =
					          HashTable_Insert(clipboard->cachedRawData,
					                           (void*)(UINT_PTR)srcFormatId, cached_raw_data)))
					{
						WLog_WARN(TAG, "Failed to cache clipboard data");
						xf_cached_data_free(cached_raw_data);
					}
				}
			}
		}

		// NOLINTNEXTLINE(clang-analyzer-unix.Malloc): HashTable_Insert takes ownership
		if (SrcSize == 0)
		{
			WLog_DBG(TAG, "skipping, empty data detected!");
			goto out;
		}

		if (!bSuccess)
		{
			ClipboardLock(clipboard->system);
			bSuccess = ClipboardSetData(clipboard->system, srcFormatId, data, SrcSize);
			ClipboardUnlock(clipboard->system);
		}

		if (!bSuccess)
		{
			WLog_DBG(TAG, "skipping, ClipboardSetData failed!");
			goto out;
		}

		wHashTable* table = clipboard->cachedData;
		if (pending->data_raw_format)
			table = clipboard->cachedRawData;

		HashTable_Lock(table);

		if (!pending->data_raw_format)
			hit_cached_data = HashTable_GetItemValue(table, format_to_cache_slot(dstFormatId));
		else
			hit_cached_data = HashTable_GetItemValue(table, format_to_cache_slot(srcFormatId));

		HashTable_Unlock(table);

		DEBUG_CLIPRDR("hasCachedData: %u, pending->data_raw_format: %d", hit_cached_data ? 1u : 0u,
		              pending->data_raw_format);

		ClipboardLock(clipboard->system);
		if (hit_cached_data)
		{
			pDstData = hit_cached_data->data;
			DstSize = hit_cached_data->data_length;
		}
		else
		{
			pDstData = (BYTE*)ClipboardGetData(clipboard->system, dstFormatId, &DstSize);
		}

		if (!pDstData)
		{
			WLog_WARN(TAG, "failed to get clipboard data in format %s [source format %s]",
			          ClipboardGetFormatName(clipboard->system, dstFormatId),
			          ClipboardGetFormatName(clipboard->system, srcFormatId));
		}
		ClipboardUnlock(clipboard->system);

		if (!pDstData)
		{
			pending->expectedResponse->property = None;
			goto out;
		}

		if (nullTerminated && pDstData)
		{
			BYTE* nullTerminator = memchr(pDstData, '\0', DstSize);
			if (nullTerminator)
			{
				const intptr_t diff = nullTerminator - pDstData;
				WINPR_ASSERT(diff >= 0);
				WINPR_ASSERT(diff <= UINT32_MAX);
				DstSize = (UINT32)diff;
			}
		}

		// clipboard->cachedRawData owns cached_raw_data
		// NOLINTNEXTLINE(clang-analyzer-unix.Malloc)
		xf_cliprdr_provide_data(clipboard, pending->expectedResponse, pDstData, DstSize);

		if (!hit_cached_data && pDstData)
		{
			cached_data = xf_cached_data_new(pDstData, DstSize);
			if (!cached_data)
			{

				free(pDstData);
				WLog_WARN(TAG, "Failed to allocate cache entry");
			}
			else
			{
				HashTable_Lock(clipboard->cachedData);
				if (!HashTable_Insert(clipboard->cachedData, format_to_cache_slot(dstFormatId),
				                      cached_data))
				{
					WLog_WARN(TAG, "Failed to cache clipboard data");
					xf_cached_data_free(cached_data);
				}
				// NOLINTNEXTLINE(clang-analyzer-unix.Malloc): HashTable_Insert takes ownership
				HashTable_Unlock(clipboard->cachedData);
			}
		}

	out:
		xf_cliprdr_provide_selection(clipboard, pending->expectedResponse);

		ArrayList_Remove(clipboard->pending_responses, pending);
	}

	// Processing data request for next formatId
	WINPR_ASSERT(ArrayList_Count(clipboard->pending_responses) == 0);

	SelectionResponse* next = ArrayList_GetItem(clipboard->queued_responses, 0);
	if (next)
	{
		UINT32 nextFormatId = next->requestedFormat->formatToRequest;
		const xfCliprdrFormat* cformat =
		    xf_cliprdr_get_client_format_by_atom(clipboard, next->expectedResponse->target);

		size_t index = 1;
		while ((next = ArrayList_GetItem(clipboard->queued_responses, index)) != nullptr)
		{
			if (next->requestedFormat->formatToRequest == nextFormatId)
			{
				/* First set item to nullptr, then remove/free the element. Avoids double free */
				if (!ArrayList_SetItem(clipboard->queued_responses, index, nullptr))
					goto fail;
				ArrayList_RemoveAt(clipboard->queued_responses, index);
				if (!ArrayList_Append(clipboard->pending_responses, next))
				{
					selection_response_free(next);
				}
			}
			else
				index++;
		}

	fail:
		xf_cliprdr_send_data_request(clipboard, nextFormatId, cformat);
	}

	ArrayList_Unlock(clipboard->queued_responses);
	ArrayList_Unlock(clipboard->pending_responses);
	xf_unlock_x11(xfc);

	return CHANNEL_RC_OK;
}

static BOOL xf_cliprdr_is_valid_unix_filename(LPCWSTR filename)
{
	if (!filename)
		return FALSE;

	if (filename[0] == L'\0')
		return FALSE;

	/* Reserved characters */
	for (const WCHAR* c = filename; *c; ++c)
	{
		if (*c == L'/')
			return FALSE;
	}

	return TRUE;
}

xfClipboard* xf_clipboard_new(xfContext* xfc, BOOL relieveFilenameRestriction)
{
	int n = 0;
	rdpChannels* channels = nullptr;
	xfClipboard* clipboard = nullptr;
	const char* selectionAtom = nullptr;
	xfCliprdrFormat* clientFormat = nullptr;
	wObject* obj = nullptr;

	WINPR_ASSERT(xfc);
	WINPR_ASSERT(xfc->common.context.settings);

	if (!(clipboard = (xfClipboard*)calloc(1, sizeof(xfClipboard))))
	{
		WLog_ERR(TAG, "failed to allocate xfClipboard data");
		return nullptr;
	}

	clipboard->file = cliprdr_file_context_new(clipboard);
	if (!clipboard->file)
		goto fail;

	xfc->clipboard = clipboard;
	clipboard->xfc = xfc;
	channels = xfc->common.context.channels;
	clipboard->channels = channels;
	clipboard->system = ClipboardCreate();
	clipboard->requestedFormatId = UINT32_MAX;
	clipboard->root_window = DefaultRootWindow(xfc->display);

	selectionAtom =
	    freerdp_settings_get_string(xfc->common.context.settings, FreeRDP_ClipboardUseSelection);
	if (!selectionAtom)
		selectionAtom = "CLIPBOARD";

	clipboard->clipboard_atom = Logging_XInternAtom(xfc->log, xfc->display, selectionAtom, FALSE);

	if (clipboard->clipboard_atom == None)
	{
		WLog_ERR(TAG, "unable to get %s atom", selectionAtom);
		goto fail;
	}

	clipboard->timestamp_property_atom =
	    Logging_XInternAtom(xfc->log, xfc->display, "_FREERDP_TIMESTAMP_PROPERTY", FALSE);
	clipboard->property_atom =
	    Logging_XInternAtom(xfc->log, xfc->display, "_FREERDP_CLIPRDR", FALSE);
	clipboard->raw_transfer_atom =
	    Logging_XInternAtom(xfc->log, xfc->display, "_FREERDP_CLIPRDR_RAW", FALSE);
	clipboard->raw_format_list_atom =
	    Logging_XInternAtom(xfc->log, xfc->display, "_FREERDP_CLIPRDR_FORMATS", FALSE);
	xf_cliprdr_set_raw_transfer_enabled(clipboard, TRUE);
	XSelectInput(xfc->display, clipboard->root_window, PropertyChangeMask);
#ifdef WITH_XFIXES

	if (XFixesQueryExtension(xfc->display, &clipboard->xfixes_event_base,
	                         &clipboard->xfixes_error_base))
	{
		int xfmajor = 0;
		int xfminor = 0;

		if (XFixesQueryVersion(xfc->display, &xfmajor, &xfminor))
		{
			XFixesSelectSelectionInput(xfc->display, clipboard->root_window,
			                           clipboard->clipboard_atom,
			                           XFixesSetSelectionOwnerNotifyMask);
			clipboard->xfixes_supported = TRUE;
		}
		else
		{
			WLog_ERR(TAG, "Error querying X Fixes extension version");
		}
	}
	else
	{
		WLog_ERR(TAG, "Error loading X Fixes extension");
	}

#else
	WLog_ERR(
	    TAG,
	    "Warning: Using clipboard redirection without XFIXES extension is strongly discouraged!");
#endif
	clientFormat = &clipboard->clientFormats[n++];
	clientFormat->atom = Logging_XInternAtom(xfc->log, xfc->display, "_FREERDP_RAW", False);
	clientFormat->localFormat = clientFormat->formatToRequest = CF_RAW;

	clientFormat = &clipboard->clientFormats[n++];
	clientFormat->atom = Logging_XInternAtom(xfc->log, xfc->display, "UTF8_STRING", False);
	clientFormat->formatToRequest = CF_UNICODETEXT;
	clientFormat->localFormat = ClipboardGetFormatId(xfc->clipboard->system, mime_text_plain);

	clientFormat = &clipboard->clientFormats[n++];
	clientFormat->atom = XA_STRING;
	clientFormat->formatToRequest = CF_TEXT;
	clientFormat->localFormat = ClipboardGetFormatId(xfc->clipboard->system, mime_text_plain);

	clientFormat = &clipboard->clientFormats[n++];
	clientFormat->atom = Logging_XInternAtom(xfc->log, xfc->display, mime_tiff, False);
	clientFormat->formatToRequest = clientFormat->localFormat = CF_TIFF;

	for (size_t x = 0; x < ARRAYSIZE(mime_bitmap); x++)
	{
		const char* mime_bmp = mime_bitmap[x];
		const DWORD format = ClipboardGetFormatId(xfc->clipboard->system, mime_bmp);
		if (format == 0)
		{
			WLog_DBG(TAG, "skipping local bitmap format %s [NOT SUPPORTED]", mime_bmp);
			continue;
		}

		WLog_DBG(TAG, "register local bitmap format %s [0x%08" PRIx32 "]", mime_bmp, format);
		clientFormat = &clipboard->clientFormats[n++];
		clientFormat->localFormat = format;
		clientFormat->atom = Logging_XInternAtom(xfc->log, xfc->display, mime_bmp, False);
		clientFormat->formatToRequest = CF_DIB;
		clientFormat->isImage = TRUE;
	}

	for (size_t x = 0; x < ARRAYSIZE(mime_images); x++)
	{
		const char* mime_bmp = mime_images[x];
		const DWORD format = ClipboardGetFormatId(xfc->clipboard->system, mime_bmp);
		if (format == 0)
		{
			WLog_DBG(TAG, "skipping local bitmap format %s [NOT SUPPORTED]", mime_bmp);
			continue;
		}

		WLog_DBG(TAG, "register local bitmap format %s [0x%08" PRIx32 "]", mime_bmp, format);
		clientFormat = &clipboard->clientFormats[n++];
		clientFormat->localFormat = format;
		clientFormat->atom = Logging_XInternAtom(xfc->log, xfc->display, mime_bmp, False);
		clientFormat->formatToRequest = CF_DIB;
		clientFormat->isImage = TRUE;
	}

	clientFormat = &clipboard->clientFormats[n++];
	clientFormat->atom = Logging_XInternAtom(xfc->log, xfc->display, mime_html, False);
	clientFormat->formatToRequest = ClipboardGetFormatId(xfc->clipboard->system, type_HtmlFormat);
	clientFormat->localFormat = ClipboardGetFormatId(xfc->clipboard->system, mime_html);
	clientFormat->formatName = _strdup(type_HtmlFormat);

	if (!clientFormat->formatName)
		goto fail;

	clientFormat = &clipboard->clientFormats[n++];

	/*
	 * Existence of registered format IDs for file formats does not guarantee that they are
	 * in fact supported by wClipboard (as further initialization may have failed after format
	 * registration). However, they are definitely not supported if there are no registered
	 * formats. In this case we should not list file formats in TARGETS.
	 */
	{
		const UINT32 fgid = ClipboardGetFormatId(clipboard->system, type_FileGroupDescriptorW);
		{
			const UINT32 uid = ClipboardGetFormatId(clipboard->system, mime_uri_list);
			if (uid)
			{
				if (!cliprdr_file_context_set_locally_available(clipboard->file, TRUE))
					goto fail;
				clientFormat->atom =
				    Logging_XInternAtom(xfc->log, xfc->display, mime_uri_list, False);
				clientFormat->localFormat = uid;
				clientFormat->formatToRequest = fgid;
				clientFormat->formatName = _strdup(type_FileGroupDescriptorW);

				if (!clientFormat->formatName)
					goto fail;

				clientFormat = &clipboard->clientFormats[n++];
			}
		}

		{
			const UINT32 gid = ClipboardGetFormatId(clipboard->system, mime_gnome_copied_files);
			if (gid != 0)
			{
				if (!cliprdr_file_context_set_locally_available(clipboard->file, TRUE))
					goto fail;
				clientFormat->atom =
				    Logging_XInternAtom(xfc->log, xfc->display, mime_gnome_copied_files, False);
				clientFormat->localFormat = gid;
				clientFormat->formatToRequest = fgid;
				clientFormat->formatName = _strdup(type_FileGroupDescriptorW);

				if (!clientFormat->formatName)
					goto fail;

				clientFormat = &clipboard->clientFormats[n++];
			}
		}

		{
			const UINT32 mid = ClipboardGetFormatId(clipboard->system, mime_mate_copied_files);
			if (mid != 0)
			{
				if (!cliprdr_file_context_set_locally_available(clipboard->file, TRUE))
					goto fail;
				clientFormat->atom =
				    Logging_XInternAtom(xfc->log, xfc->display, mime_mate_copied_files, False);
				clientFormat->localFormat = mid;
				clientFormat->formatToRequest = fgid;
				clientFormat->formatName = _strdup(type_FileGroupDescriptorW);

				if (!clientFormat->formatName)
					goto fail;
			}
		}
	}

	clipboard->numClientFormats = WINPR_ASSERTING_INT_CAST(uint32_t, n);
	clipboard->targets[0] = Logging_XInternAtom(xfc->log, xfc->display, "TIMESTAMP", FALSE);
	clipboard->targets[1] = Logging_XInternAtom(xfc->log, xfc->display, "TARGETS", FALSE);
	clipboard->numTargets = 2;
	clipboard->incr_atom = Logging_XInternAtom(xfc->log, xfc->display, "INCR", FALSE);

	if (relieveFilenameRestriction)
	{
		WLog_DBG(TAG, "Relieving CLIPRDR filename restriction");
		ClipboardGetDelegate(clipboard->system)->IsFileNameComponentValid =
		    xf_cliprdr_is_valid_unix_filename;
	}

	clipboard->cachedData = HashTable_New(TRUE);
	if (!clipboard->cachedData)
		goto fail;

	obj = HashTable_ValueObject(clipboard->cachedData);
	obj->fnObjectFree = xf_cached_data_free;

	clipboard->cachedRawData = HashTable_New(TRUE);
	if (!clipboard->cachedRawData)
		goto fail;

	obj = HashTable_ValueObject(clipboard->cachedRawData);
	obj->fnObjectFree = xf_cached_data_free;

	clipboard->pending_responses = ArrayList_New(TRUE);
	if (!clipboard->pending_responses)
		goto fail;
	obj = ArrayList_Object(clipboard->pending_responses);
	obj->fnObjectFree = selection_response_free;

	clipboard->queued_responses = ArrayList_New(TRUE);
	if (!clipboard->queued_responses)
		goto fail;
	obj = ArrayList_Object(clipboard->queued_responses);
	obj->fnObjectFree = selection_response_free;

	return clipboard;

fail:
	WINPR_PRAGMA_DIAG_PUSH
	WINPR_PRAGMA_DIAG_IGNORED_MISMATCHED_DEALLOC
	xf_clipboard_free(clipboard);
	WINPR_PRAGMA_DIAG_POP
	return nullptr;
}

void xf_clipboard_free(xfClipboard* clipboard)
{
	if (!clipboard)
		return;

	xf_clipboard_free_server_formats(clipboard);

	if (clipboard->numClientFormats)
	{
		for (UINT32 i = 0; i < clipboard->numClientFormats; i++)
		{
			xfCliprdrFormat* format = &clipboard->clientFormats[i];
			free(format->formatName);
		}
	}

	cliprdr_file_context_free(clipboard->file);

	ClipboardDestroy(clipboard->system);
	HashTable_Free(clipboard->cachedRawData);
	HashTable_Free(clipboard->cachedData);
	ArrayList_Free(clipboard->pending_responses);
	ArrayList_Free(clipboard->queued_responses);
	free(clipboard->incr_data);
	free(clipboard);
}

void xf_cliprdr_init(xfContext* xfc, CliprdrClientContext* cliprdr)
{
	WINPR_ASSERT(xfc);
	WINPR_ASSERT(cliprdr);

	xfc->cliprdr = cliprdr;
	xfc->clipboard->context = cliprdr;

	cliprdr->MonitorReady = xf_cliprdr_monitor_ready;
	cliprdr->ServerCapabilities = xf_cliprdr_server_capabilities;
	cliprdr->ServerFormatList = xf_cliprdr_server_format_list;
	cliprdr->ServerFormatListResponse = xf_cliprdr_server_format_list_response;
	cliprdr->ServerFormatDataRequest = xf_cliprdr_server_format_data_request;
	cliprdr->ServerFormatDataResponse = xf_cliprdr_server_format_data_response;

	cliprdr_file_context_init(xfc->clipboard->file, cliprdr);
}

void xf_cliprdr_uninit(xfContext* xfc, CliprdrClientContext* cliprdr)
{
	WINPR_ASSERT(xfc);

	xfc->cliprdr = nullptr;

	if (xfc->clipboard)
	{
		ClipboardLock(xfc->clipboard->system);
		cliprdr_file_context_uninit(xfc->clipboard->file, cliprdr);
		ClipboardUnlock(xfc->clipboard->system);
		xfc->clipboard->context = nullptr;
	}
}
